<footer>
    <p> Bake It Til You Make It - COMP1006 </p>
    <p> Week 4 - Form Validation</p>
  </footer>